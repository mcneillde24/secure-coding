// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits> // For std::numeric_limits

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;
	//FIXED: the user can type up to 19 characters, and the 20th character will cause a buffer overflow.
	// The account_number variable is a constant and its position in the declaration will not change.
	// The user will be notified if they entered too much data.

	const std::string account_number = "CharlieBrown42";
	char user_input[20];
	std::cout << "Enter a value: ";

	// Using std::cin.getline to limit input to prevent buffer overflow
	std::cin.getline(user_input, sizeof(user_input));

	//check if the input was too long
	if (std::cin.fail()) {
		std::cout << "Input too long! Please enter up to 19 characters." << std::endl;
		std::cin.clear(); // Clear the error flag
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard the rest of the input
	}

	std::cout << "You entered: " << user_input << std::endl;
	std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
