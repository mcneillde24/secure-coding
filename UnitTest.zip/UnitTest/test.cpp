// Uncomment the next line to use precompiled headers
//#include "pch.h"
// Uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
#include <vector>
#include <memory>
#include <cstdlib>
#include <ctime>
#include <cassert>

// Global test environment setup and teardown
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  void SetUp() override
  {
    // Initialize random seed once per test run
    srand(static_cast<unsigned>(time(nullptr)));
  }

  void TearDown() override {}
};

// Test fixture class housing shared collection data and helpers
class CollectionTest : public ::testing::Test
{
protected:
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  {
    // Create a fresh empty collection before each test
    collection.reset(new std::vector<int>);
  }

  void TearDown() override
  {
    // Clear and destroy collection after each test
    collection->clear();
    collection.reset(nullptr);
  }

  // Helper to add 'count' random values between 0 and 99 inclusive
  void add_entries(int count)
  {
    assert(count > 0);
    for (int i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// Test 1: Verify the smart pointer holds the vector and is not a nullptr
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  ASSERT_TRUE(collection);
  ASSERT_NE(collection.get(), nullptr);
}

// Test 2: Verify the vector is empty when created
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);
}

// Test 3: Intentional failure test
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}

// Test 4: Verify adding a single value to an empty vector
TEST_F(CollectionTest, CanAddSingleValueToEmptyVector)
{
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);

  add_entries(1);

  EXPECT_FALSE(collection->empty());
  EXPECT_EQ(collection->size(), 1);
}

// Test 5: Verify adding five values to the vector
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  ASSERT_TRUE(collection->empty());

  add_entries(5);

  EXPECT_FALSE(collection->empty());
  EXPECT_EQ(collection->size(), 5);
}

// Test 6: Verify max size is always at least the current size
TEST_F(CollectionTest, MaxSizeIsGreaterOrEqualToSize)
{
  EXPECT_GE(collection->max_size(), collection->size());

  add_entries(1);
  EXPECT_GE(collection->max_size(), collection->size());

  collection->clear();
  add_entries(5);
  EXPECT_GE(collection->max_size(), collection->size());

  collection->clear();
  add_entries(10);
  EXPECT_GE(collection->max_size(), collection->size());
}

// Test 7: Verify the vector capacity is greater than or equal to the size
TEST_F(CollectionTest, CapacityIsGreaterOrEqualToSize)
{
  EXPECT_GE(collection->capacity(), collection->size());

  add_entries(1);
  EXPECT_GE(collection->capacity(), collection->size());

  collection->clear();
  add_entries(5);
  EXPECT_GE(collection->capacity(), collection->size());

  collection->clear();
  add_entries(10);
  EXPECT_GE(collection->capacity(), collection->size());
}

// Test 8: Test increasing the size of the vector
TEST_F(CollectionTest, ResizingIncreasesCollection)
{
  ASSERT_TRUE(collection->empty());

  collection->resize(10);

  EXPECT_EQ(collection->size(), 10);
}

// Test 9: Test decreasing the size of the vector
TEST_F(CollectionTest, ResizingDecreasesCollection)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10);

  collection->resize(5);

  EXPECT_EQ(collection->size(), 5);
}

// Test 10: Test resizing to zero to empty the vector
TEST_F(CollectionTest, ResizingToZeroClearsCollection)
{
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  collection->resize(0);

  EXPECT_EQ(collection->size(), 0);
  EXPECT_TRUE(collection->empty());
}

// Test 11: Test that clears the vector
TEST_F(CollectionTest, ClearErasesCollection)
{
  add_entries(5);
  ASSERT_FALSE(collection->empty());

  collection->clear();

  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

// Test 12: Erase the elements from begin to end
TEST_F(CollectionTest, EraseBeginToEndErasesCollection)
{
  add_entries(5);
  ASSERT_FALSE(collection->empty());

  collection->erase(collection->begin(), collection->end());

  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

// Test 13: Increase the capacity without changing the size
TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize)
{
  add_entries(5);
  size_t old_size = collection->size();
  size_t old_capacity = collection->capacity();

  collection->reserve(old_capacity + 10);

  EXPECT_EQ(collection->size(), old_size);
  EXPECT_GE(collection->capacity(), old_capacity + 10);
}

// Test 14 (Negative): test that accessing the out of bounds throws the exception
TEST_F(CollectionTest, AtThrowsOutOfRangeForInvalidIndex)
{
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  EXPECT_THROW(collection->at(10), std::out_of_range);
}

// Test 15 (Positive): Check that front returns the first element
TEST_F(CollectionTest, FrontReturnsFirstElement)
{
  collection->push_back(42);
  collection->push_back(7);

  ASSERT_FALSE(collection->empty());

  EXPECT_EQ(collection->front(), 42);
}

// Test 16 (Negative): Verify that vector remains valid after erase with invalid range
TEST_F(CollectionTest, EraseWithInvalidRangeDoesNotCrash)
{
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  // Try erasing with invalid range
  try {
    collection->erase(collection->end(), collection->begin());
  } catch (...) {
    FAIL() << "erase() with invalid range threw an exception";
  }

  // Size should be unchanged
  EXPECT_EQ(collection->size(), 5);
}
